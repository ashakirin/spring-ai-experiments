package com.infobip.agent.whatsapp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class McpClientConfig {

    /**
     * Adds the Infobip API key to every MCP request as {@code Authorization: App <key>}.
     * Picked up by the Streamable HTTP (WebFlux) MCP client transport.
     */
    @Bean
    WebClient.Builder apiKeyInjectingWebClientBuilder(@Value("${infobip.api.key}") String apiKey) {
        return WebClient.builder().apply(builder -> builder
                .defaultHeader(HttpHeaders.AUTHORIZATION, "App %s".formatted(apiKey))
        );
    }
}
