# WhatsApp/SMS MCP Agent (Streamable HTTP)

A Spring Boot + [Spring AI](https://docs.spring.io/spring-ai/reference/) agent that connects to the
[Infobip remote MCP server](https://github.com/infobip/mcp) over **Streamable HTTP** and lets you send
messages (SMS, MMS, RCS, Viber, WhatsApp) from natural-language prompts. The language model runs on
**Amazon Bedrock**; message sending is performed through Infobip's hosted MCP `message` server.

## How it works

```
HTTP client ──▶ /api/chat ──▶ Spring AI ChatClient ──▶ Amazon Bedrock (Claude)
                                     │
                                     └── MCP tool call ──▶ https://mcp.infobip.com/message ──▶ Infobip ──▶ phone
```

- The model decides when to call the Infobip `send` tool based on your prompt.
- The MCP transport is **Streamable HTTP**; authentication is a single `Authorization: App <API_KEY>` header,
  injected via a `WebClient.Builder` bean (`McpClientConfig`).
- Chat history is kept in an in-memory sliding window (last 20 messages) via Spring AI chat memory.

## Requirements

- **Java 21**
- **Maven** (or the bundled `./mvnw`)
- **Amazon Bedrock access** with a Claude model enabled in a US region (the default model is a
  `us.` cross-region inference profile)
- An **Infobip API key** with messaging scope (see the [Infobip MCP docs](https://github.com/infobip/mcp))

> Infobip resolves your account — and its data-center base URL — from the API key, so no account base
> URL needs to be configured in this app. On trial accounts you can typically only send to numbers
> verified on the account.

## Environment variables

Set these before running. The Infobip key and AWS credentials are **secrets** — do not commit them.

| Variable | Required | Purpose | Example |
|---|---|---|---|
| `INFOBIP_API_KEY` | ✅ | Infobip API key. Spring maps it to the `infobip.api.key` property and sends it as `Authorization: App <key>`. | `4fac…-…-…` |
| `AWS_REGION` | ✅ | Bedrock region (must offer the configured model). | `us-east-1` |
| `AWS_PROFILE` | ⬦ | Named profile from `~/.aws` for Bedrock credentials. Use this **or** the explicit keys below. | `default` |
| `AWS_ACCESS_KEY_ID` | ⬦ | Bedrock access key (if not using `AWS_PROFILE`). | `AKIA…` |
| `AWS_SECRET_ACCESS_KEY` | ⬦ | Bedrock secret key (if not using `AWS_PROFILE`). | `…` |
| `AWS_SESSION_TOKEN` | ⬦ | Session token (only for temporary/STS credentials). | `…` |

⬦ = optional; provide credentials **either** via `AWS_PROFILE` **or** the explicit `AWS_*` keys.

```bash
export INFOBIP_API_KEY='your-infobip-api-key'
export AWS_PROFILE=default          # or AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY
export AWS_REGION=us-east-1
```

## Configuration

Defaults live in [`src/main/resources/application.properties`](src/main/resources/application.properties):

| Property | Default | Notes |
|---|---|---|
| `spring.ai.mcp.client.streamable-http.connections.server1.url` | `https://mcp.infobip.com` | MCP server base URL |
| `spring.ai.mcp.client.streamable-http.connections.server1.endpoint` | `/message` | Messages MCP endpoint (append `/sse` only if using the SSE variant) |
| `spring.ai.bedrock.converse.chat.options.model` | `us.anthropic.claude-sonnet-4-5-20250929-v1:0` | Any Bedrock Claude model/inference profile enabled in your account |
| `infobip.api.key` | `DEFINED_IN_VARIABLE` | Overridden at runtime by `INFOBIP_API_KEY` |

To target a different Infobip channel/server (e.g. `sms`, `whatsapp`), change the `endpoint` value.

## Build & run

```bash
# build
./mvnw clean package

# run (uses the environment variables above)
./mvnw spring-boot:run
```

The app starts on **http://localhost:8080**.

## Usage

Send a message by describing it in natural language:

```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Send an SMS to +49XXXXXXXXXXX with the text: Hello from Spring AI + Infobip MCP."}'
```

Streaming variant:

```bash
curl -X POST http://localhost:8080/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Send an SMS to +49XXXXXXXXXXX saying the workshop starts at 10:00."}'
```

### Endpoints

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/chat` | Prompt in, assistant reply out (may trigger a message send). |
| `POST` | `/api/chat/stream` | Same, streamed as `text/event-stream`. |

Request body: `{"prompt": "..."}`.

## Versions

- Spring AI **2.0.1**
- Spring Boot **4.0.0**
- Java **21**
